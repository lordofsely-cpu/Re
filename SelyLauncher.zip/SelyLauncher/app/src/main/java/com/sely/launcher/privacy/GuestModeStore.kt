package com.sely.launcher.privacy

import android.content.Context

/**
 * Sely Privacy Center — "Guest Space" (spec section 9 + section 36).
 *
 * 🔴 Stated plainly, exactly as spec §9 requires: this is NOT true
 * OS-level app isolation or a separate user profile. It's a
 * launcher-level visibility filter — while active, Home/Drawer/Search
 * show only the apps on the allowlist. It does not stop someone from
 * reaching every other app via Android's own Settings, a different
 * launcher, or (if no PIN is set) simply reopening Sely's own Settings
 * and turning Guest Space back off. Setting a Launcher PIN
 * (`PrivacyLockStore`) closes that specific hole by gating Settings and
 * App Management while Guest Space is on — real, but still a launcher-
 * level lock, not a system one.
 */
object GuestModeStore {
    private const val PREFS = "sely_guest_mode"
    private const val KEY_ACTIVE = "active"
    private const val KEY_ALLOWLIST = "allowlist"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isActive(context: Context) = prefs(context).getBoolean(KEY_ACTIVE, false)

    fun setActive(context: Context, active: Boolean) {
        prefs(context).edit().putBoolean(KEY_ACTIVE, active).apply()
    }

    fun getAllowlist(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_ALLOWLIST, emptySet()) ?: emptySet()

    fun setAllowed(context: Context, packageName: String, allowed: Boolean) {
        val current = getAllowlist(context).toMutableSet()
        if (allowed) current.add(packageName) else current.remove(packageName)
        prefs(context).edit().putStringSet(KEY_ALLOWLIST, current).apply()
    }
}

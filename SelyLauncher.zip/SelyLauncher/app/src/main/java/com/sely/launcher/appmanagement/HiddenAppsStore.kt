package com.sely.launcher.appmanagement

import android.content.Context

/**
 * Sely App Management (spec section 35) + Privacy Center's "Hidden
 * apps" (section 9) — same underlying store, since both describe the
 * same real capability.
 *
 * 🟢 This is launcher-level hiding: hidden apps are filtered out of
 * Sely's own Home grid, App Drawer, and Search results. It is NOT
 * system-level app hiding or sandboxing — the app is still installed,
 * still visible in Android Settings > Apps, and still launchable by
 * any other launcher or via a direct intent. No third-party launcher
 * API can change that, and this store doesn't pretend otherwise.
 */
object HiddenAppsStore {
    private const val PREFS = "sely_hidden_apps"
    private const val KEY_HIDDEN = "hidden_packages"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getHidden(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_HIDDEN, emptySet()) ?: emptySet()

    fun isHidden(context: Context, packageName: String) = getHidden(context).contains(packageName)

    fun setHidden(context: Context, packageName: String, hidden: Boolean) {
        val current = getHidden(context).toMutableSet()
        if (hidden) current.add(packageName) else current.remove(packageName)
        prefs(context).edit().putStringSet(KEY_HIDDEN, current).apply()
    }
}

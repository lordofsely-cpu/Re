package com.sely.launcher.modes

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import com.sely.launcher.performance.PerformanceModeStore
import com.sely.launcher.theme.ThemeManager

object ModeApplier {
    /** Applies every real lever a ModeProfile controls. Returns true if DND needed a permission the user hasn't granted yet. */
    fun apply(context: Context, profile: ModeProfile): Boolean {
        ThemeManager.setAccentColor(context, profile.accentColor)
        ThemeManager.setDark(context, profile.isDark)
        PerformanceModeStore.setMode(context, profile.performanceMode)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            if (profile.dndOn) {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                Toast.makeText(context, "Grant notification access to let modes control Do Not Disturb", Toast.LENGTH_LONG).show()
                return true
            }
            return false
        }
        nm.setInterruptionFilter(
            if (profile.dndOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return false
    }
}

package com.sely.launcher.commandcenter

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.R
import com.sely.launcher.controlcenter.ControlTile
import com.sely.launcher.controlcenter.ControlTileAdapter
import com.sely.launcher.dashboard.DeviceStats
import com.sely.launcher.databinding.ActivityCommandCenterBinding
import com.sely.launcher.network.NetworkStats
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Command Center (spec section 37) — "one central dashboard...
 * This should feel like the central command center of Sely Launcher."
 *
 * This is an aggregator, not a new subsystem: the live stats row reuses
 * DeviceStats and NetworkStats exactly as built for Battery/Device
 * Dashboard and Network Center (same real APIs, no duplicated logic),
 * and the action grid reuses ControlTile/ControlTileAdapter (already
 * generic — label, icon, onClick) to link every screen built so far.
 *
 * Sely Transfer is deliberately absent from the grid: it doesn't exist
 * yet, and a tile that opens nothing would be exactly the kind of fake
 * functionality this project avoids everywhere else.
 */
class CommandCenterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCommandCenterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCommandCenterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.actionGrid.layoutManager = GridLayoutManager(this, 4)
        binding.actionGrid.adapter = ControlTileAdapter(this, buildTiles())
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        buildStatsRow()
    }

    private fun applyTheme() {
        ThemeManager.applyScreenBackground(binding.commandRoot)
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
    }

    private fun buildStatsRow() {
        binding.statsRow.removeAllViews()
        val battery = DeviceStats.battery(this)
        val memory = DeviceStats.memory(this)
        val network = NetworkStats.snapshot(this)

        addStat("${battery.percent}%", if (battery.isCharging) "Battery · Charging" else "Battery")
        val usedMem = memory.totalBytes - memory.availableBytes
        addStat(DeviceStats.formatBytes(usedMem), "RAM used")
        val networkLabel = if (network.connectionType == "No connection") "Offline" else network.connectionType
        addStat(networkLabel, "Network")
    }

    private fun addStat(value: String, label: String) {
        val card = LayoutInflater.from(this).inflate(R.layout.item_stat_card, binding.statsRow, false)
        card.findViewById<TextView>(R.id.statValue).apply {
            text = value
            setTextColor(ThemeManager.accentColor(this@CommandCenterActivity))
        }
        card.findViewById<TextView>(R.id.statLabel).apply {
            text = label
            setTextColor(ThemeManager.textSecondary(this@CommandCenterActivity))
        }
        binding.statsRow.addView(card)
    }

    private fun buildTiles(): List<ControlTile> = listOf(
        ControlTile("Apps", com.sely.launcher.R.drawable.ic_sely_command) {
            startActivity(Intent(this, com.sely.launcher.drawer.AppDrawerActivity::class.java))
        },
        ControlTile("Manage Apps", com.sely.launcher.R.drawable.ic_sely_settings) {
            startActivity(Intent(this, com.sely.launcher.appmanagement.AppManagementActivity::class.java))
        },
        ControlTile("Game Mode", com.sely.launcher.R.drawable.ic_sely_record) {
            startActivity(Intent(this, com.sely.launcher.gamemode.GameModeActivity::class.java))
        },
        ControlTile("Modes", com.sely.launcher.R.drawable.ic_sely_palette) {
            startActivity(Intent(this, com.sely.launcher.modes.ModesActivity::class.java))
        },
        ControlTile("Privacy", com.sely.launcher.R.drawable.ic_sely_settings) {
            startActivity(Intent(this, com.sely.launcher.privacy.PrivacyCenterActivity::class.java))
        },
        ControlTile("Recents", com.sely.launcher.R.drawable.ic_sely_recents) {
            startActivity(Intent(this, com.sely.launcher.multitask.MultitaskHubActivity::class.java))
        },
        ControlTile("Controls", com.sely.launcher.R.drawable.ic_sely_switch) {
            startActivity(Intent(this, com.sely.launcher.controlcenter.ControlCenterActivity::class.java))
        },
        ControlTile("Notifications", com.sely.launcher.R.drawable.ic_sely_bell) {
            startActivity(Intent(this, com.sely.launcher.notifications.NotificationCenterActivity::class.java))
        },
        ControlTile("Battery & Device", com.sely.launcher.R.drawable.ic_sely_device) {
            startActivity(Intent(this, com.sely.launcher.dashboard.DeviceDashboardActivity::class.java))
        },
        ControlTile("Network", com.sely.launcher.R.drawable.ic_sely_network) {
            startActivity(Intent(this, com.sely.launcher.network.NetworkCenterActivity::class.java))
        },
        ControlTile("File Hub", com.sely.launcher.R.drawable.ic_sely_files) {
            startActivity(Intent(this, com.sely.launcher.filehub.FileHubActivity::class.java))
        },
        ControlTile("Clipboard", com.sely.launcher.R.drawable.ic_sely_clipboard) {
            startActivity(Intent(this, com.sely.launcher.clipboard.ClipboardManagerActivity::class.java))
        },
        ControlTile("QR Scan", com.sely.launcher.R.drawable.ic_sely_qr) {
            startActivity(Intent(this, com.sely.launcher.qrscanner.QrScannerActivity::class.java))
        },
        ControlTile("Screenshot", com.sely.launcher.R.drawable.ic_sely_camera) {
            startActivity(Intent(this, com.sely.launcher.screenshotstudio.ScreenshotStudioActivity::class.java))
        },
        ControlTile("Screen Record", com.sely.launcher.R.drawable.ic_sely_record) {
            startActivity(Intent(this, com.sely.launcher.screenrecorder.ScreenRecorderActivity::class.java))
        },
        ControlTile("Wallpaper", com.sely.launcher.R.drawable.ic_sely_image) {
            startActivity(Intent(this, com.sely.launcher.wallpaper.WallpaperActivity::class.java))
        },
        ControlTile("Theme", com.sely.launcher.R.drawable.ic_sely_palette) {
            startActivity(Intent(this, com.sely.launcher.theme.ThemeActivity::class.java))
        },
        ControlTile("Search", com.sely.launcher.R.drawable.ic_sely_search) {
            startActivity(Intent(this, com.sely.launcher.search.SearchActivity::class.java))
        },
        ControlTile("Settings", com.sely.launcher.R.drawable.ic_sely_settings) {
            startActivity(Intent(this, com.sely.launcher.SettingsActivity::class.java))
        }
    )
}

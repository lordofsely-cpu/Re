package com.sely.launcher

import android.content.Context
import android.content.Intent

/** Single source of truth for "what apps are installed and launchable". */
object AppRepository {

    // Loading every app label + icon from PackageManager is slow (hundreds
    // of milliseconds to seconds on low-end phones). Doing that on the main
    // thread is what caused "Sely Launcher isn't responding". It now runs on
    // a background thread, and the result is cached so other screens
    // (drawer, search, sidebar) can reuse it instantly.
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    @Volatile
    private var cache: List<AppInfo>? = null

    private fun keyOf(apps: List<AppInfo>): List<String> =
        apps.map { it.packageName + "/" + it.activityName }

    /**
     * Applies both real launcher-level visibility filters: hidden apps
     * (App Management) and, when Guest Space is active, the guest
     * allowlist (Privacy Center) — see GuestModeStore's class doc for
     * exactly what this is and isn't a security boundary against.
     */
    private fun filterHidden(context: Context, apps: List<AppInfo>): List<AppInfo> {
        val hidden = com.sely.launcher.appmanagement.HiddenAppsStore.getHidden(context)
        var result = apps.filterNot { hidden.contains(it.packageName) }
        if (com.sely.launcher.privacy.GuestModeStore.isActive(context)) {
            val allowlist = com.sely.launcher.privacy.GuestModeStore.getAllowlist(context)
            result = result.filter { allowlist.contains(it.packageName) }
        }
        return result
    }

    /**
     * Delivers the visible app list on the main thread without blocking it.
     * If a cached list exists it is delivered immediately, then the list is
     * refreshed in the background and delivered again only if it changed
     * (an app was installed/removed).
     */
    fun loadVisibleAppsAsync(context: Context, onLoaded: (List<AppInfo>) -> Unit) {
        val appContext = context.applicationContext
        val cached = cache
        if (cached != null) onLoaded(filterHidden(appContext, cached))
        executor.execute {
            try {
                val fresh = loadLaunchableApps(appContext)
                val changed = cached == null || keyOf(cached) != keyOf(fresh)
                cache = fresh
                if (changed) {
                    mainHandler.post { onLoaded(filterHidden(appContext, fresh)) }
                }
            } catch (e: Exception) {
                // Never crash the launcher because one app failed to load.
            }
        }
    }

    fun loadLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .mapNotNull { resolveInfo ->
                try {
                    AppInfo(
                        label = resolveInfo.loadLabel(pm).toString(),
                        packageName = resolveInfo.activityInfo.packageName,
                        activityName = resolveInfo.activityInfo.name,
                        icon = resolveInfo.loadIcon(pm)
                    )
                } catch (e: Exception) {
                    null
                }
            }
            .sortedBy { it.label.lowercase() }
    }

    /**
     * Resolves a single app by package/activity name, for screens (like
     * Multitask Hub) that persist just those two strings and need to
     * look up a fresh icon/label later. Returns null if the app has
     * since been uninstalled, so callers can drop it quietly instead of
     * showing a broken entry.
     */
    fun resolveApp(context: Context, packageName: String, activityName: String): AppInfo? {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            AppInfo(
                label = pm.getApplicationLabel(appInfo).toString(),
                packageName = packageName,
                activityName = activityName,
                icon = pm.getApplicationIcon(appInfo)
            )
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Same as loadLaunchableApps, but filtered through HiddenAppsStore —
     * this is what Home, App Drawer, and Search should call, so a
     * hidden app disappears from everywhere a user actually browses
     * while still being visible in App Management (which needs the full
     * list to offer "Unhide").
     */
    fun loadVisibleApps(context: Context): List<AppInfo> {
        val cached = cache
        if (cached != null) return filterHidden(context, cached)
        val fresh = loadLaunchableApps(context)
        cache = fresh
        return filterHidden(context, fresh)
    }
}

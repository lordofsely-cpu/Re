package com.sely.launcher.screenrecorder

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat

/**
 * Sely Screen Recorder (spec section 20) — the actual capture pipeline.
 *
 * 🟢 This is Android's real, official screen-recording path, and it has
 * two requirements baked into the OS that no app can bypass:
 *  1. `MediaProjectionManager.createScreenCaptureIntent()` must show the
 *     system's own "Sely will start capturing everything on your
 *     screen" consent dialog — fresh, every single recording session.
 *     There is no way to remember a prior grant and skip it.
 *  2. Once granted, capture must run in a foreground service with a
 *     persistent, user-visible notification for the whole recording
 *     (Android requires `foregroundServiceType="mediaProjection"` since
 *     API 34) — the user always has a visible "Sely is recording your
 *     screen · Stop" affordance, by platform design, not an
 *     implementation choice here.
 *
 * Recording is video (+ optional microphone audio via
 * MediaRecorder.AudioSource.MIC — 🟢, standard and simple to include in
 * the same MediaRecorder). Device/internal audio capture
 * (AudioPlaybackCaptureConfiguration) is a real but meaningfully more
 * complex feature — mixing a second AudioRecord stream into the same
 * container — and is intentionally left as a noted next increment
 * rather than half-built here.
 *
 * Saves via MediaStore (Movies/Sely), using the IS_PENDING flag so the
 * file only becomes visible to other apps once recording finishes
 * cleanly — the same officially-recommended pattern used elsewhere in
 * this project for scoped-storage writes.
 */
class ScreenRecordService : Service() {

    companion object {
        const val ACTION_START = "com.sely.launcher.screenrecorder.START"
        const val ACTION_STOP = "com.sely.launcher.screenrecorder.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_RECORD_MIC = "recordMic"
        private const val CHANNEL_ID = "sely_screen_recorder"
        private const val NOTIF_ID = 9001
        var isRecording = false
            private set
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var outputUri: android.net.Uri? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                val recordMic = intent.getBooleanExtra(EXTRA_RECORD_MIC, false)
                if (resultCode == Activity.RESULT_OK && data != null) {
                    startRecording(resultCode, data, recordMic)
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopRecording()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording(resultCode: Int, data: Intent, recordMic: Boolean) {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, data)
        mediaProjection = projection
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // User revoked from the system UI (e.g. notification shade) — clean up honestly.
                stopRecording()
                stopSelf()
            }
        }, null)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val filename = "Sely_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, filename)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Sely")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            stopSelf()
            return
        }
        outputUri = uri
        val pfd = contentResolver.openFileDescriptor(uri, "rw")
        if (pfd == null) {
            stopSelf()
            return
        }

        val recorder = MediaRecorder()
        mediaRecorder = recorder
        try {
            if (recordMic) recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            if (recordMic) recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            recorder.setVideoSize(width, height)
            recorder.setVideoEncodingBitRate(8_000_000)
            recorder.setVideoFrameRate(30)
            recorder.setOutputFile(pfd.fileDescriptor)
            recorder.prepare()

            virtualDisplay = projection.createVirtualDisplay(
                "SelyScreenRecord", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                recorder.surface, null, null
            )
            recorder.start()
            isRecording = true
        } catch (e: Exception) {
            stopRecording()
            stopSelf()
        }
    }

    private fun stopRecording() {
        try {
            mediaRecorder?.apply { stop(); release() }
        } catch (e: Exception) {
            // stop() can throw if called too soon after start() — nothing
            // more to salvage, the partial file is discarded below.
        }
        virtualDisplay?.release()
        mediaProjection?.stop()
        isRecording = false

        outputUri?.let { uri ->
            val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(uri, values, null, null)
            RecordingHistoryStore.add(
                this,
                RecordingEntry(uri.toString(), "Recording", System.currentTimeMillis())
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sely is recording your screen")
            .setContentText("Tap Stop to finish")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen Recording", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isRecording) stopRecording()
    }
}
